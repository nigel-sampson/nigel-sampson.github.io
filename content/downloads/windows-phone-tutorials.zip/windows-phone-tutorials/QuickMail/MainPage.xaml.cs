﻿using System;
using System.Windows;
using System.Windows.Controls;
using QuickMail.Models;

namespace QuickMail
{
    public partial class MainPage
    {
		private readonly TemplateStorage storage = new TemplateStorage();

        public MainPage()
        {
            InitializeComponent();

        	Loaded += OnLoaded;
        }

    	private void OnLoaded(object sender, RoutedEventArgs e)
    	{
    		Templates.ItemsSource = storage.GetItems();
    	}

    	private void OnAdd(object sender, EventArgs e)
    	{
    		NavigationService.Navigate(new Uri("/EditPage.xaml", UriKind.Relative));
    	}

    	private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    	{
			if(Templates.SelectedItem == null)
				return;

    		var template = (QuickMailTemplate)Templates.SelectedItem;

			NavigationService.Navigate(new Uri("/DetailsPage.xaml?Id=" + template.Id, UriKind.Relative));

    		Templates.SelectedItem = null;
    	}
    }
}
