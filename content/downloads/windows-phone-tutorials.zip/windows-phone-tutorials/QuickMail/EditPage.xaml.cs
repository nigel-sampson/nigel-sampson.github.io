﻿using System;
using System.Linq;
using System.Windows;
using QuickMail.Models;

namespace QuickMail
{
	public partial class EditPage
	{
		private readonly TemplateStorage storage = new TemplateStorage();

		public EditPage()
		{
			InitializeComponent();

			Loaded += OnLoaded;
		}

		private Guid? TemplateId
		{
			get
			{
				if(!NavigationContext.QueryString.ContainsKey("Id"))
					return null;

				return new Guid(NavigationContext.QueryString["Id"]);
			}
		}

		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			if(TemplateId == null)
				return;

			var template = storage.GetItems()
				.Single(t => t.Id == TemplateId);

			Subject.Text = template.Subject;
			Body.Text = template.Body;
		}

		private void OnSave(object sender, EventArgs e)
		{
			QuickMailTemplate template;

			if(TemplateId == null)
			{

				template = new QuickMailTemplate
				{
					Id = Guid.NewGuid(),
					Subject = Subject.Text,
					Body = Body.Text
				};

				storage.Save(template);
			}
			else
			{
				template = storage.GetItems()
					.Single(t => t.Id == TemplateId);

				template.Subject = Subject.Text;
				template.Body = Body.Text;
			}


			storage.SaveChanges();

			NavigationService.Navigate(new Uri("/DetailsPage.xaml?Id=" + template.Id, UriKind.Relative));
		}

		private void OnCancel(object sender, EventArgs e)
		{
			NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
		}
	}
}
