﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Decisions
{
    public class DecisionType
    {
        public static IEnumerable<DecisionType> GetDecisionTypes()
        {
            return new[]
            {
                new DecisionType
                {
                    Name = "Yes / No",
                    Choices = new[]
                    {
                        "Yes", "No"
                    }
                },
                new DecisionType
                {
                    Name = "A / B / C / D",
                    Choices = new[]
                    {
                        "A", "B", "C", "D"
                    }
                },
                new DecisionType
                {
                    Name = "1 - 100",
                    Choices = Enumerable.Range(1, 100).Select(i => i.ToString())
                },
                new DecisionType
                {
                    Name = "Left / Center / Right",
                    Choices = new[]
                    {
                        "Left", "Center", "Right"
                    }
                },
                new DecisionType
                {
                    Name = "Buy / Sell / Hold",
                    Choices = new[]
                    {
                        "Buy", "Sell", "Hold"
                    }
                },
                new DecisionType
                {
                    Name = "Agree / Disagree",
                    Choices = new[]
                    {
                        "Agree", "Disagree"
                    }
                },
                new DecisionType
                {
                    Name = "Heads / Tails",
                    Choices = new[]
                    {
                        "Heads", "Tails"
                    }
                },
                 new DecisionType
                {
                    Name = "Russian Roulette",
                    Choices = Enumerable.Repeat("Click", 5).Union(new[] { "Bang" })
                },
            };
        }

        public string Name
        {
            get; set;
        }

        public IEnumerable<string> Choices
        {
            get; set;
        }
    }
}
