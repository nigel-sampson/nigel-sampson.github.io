﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace Candle
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            var storyboard = new Storyboard
            {
                RepeatBehavior = RepeatBehavior.Forever
            };

            var animation = new ObjectAnimationUsingKeyFrames();

            Storyboard.SetTarget(animation, CandleImage);
            Storyboard.SetTargetProperty(animation, new PropertyPath("Source"));

            storyboard.Children.Add(animation);

            for(int i = 1; i <= 60; i++)
            {
                var keyframe = new DiscreteObjectKeyFrame
                {
                    KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(50 * i)),
                    Value = String.Format("/Images/candle_{0:D2}.jpg", i)
                };

                animation.KeyFrames.Add(keyframe);
            }

            Resources.Add("CandleStoryboard", storyboard);

            storyboard.Begin();
        }
    }
}
