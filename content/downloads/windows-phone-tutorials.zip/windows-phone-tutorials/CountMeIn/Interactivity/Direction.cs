﻿using System;

namespace CountMeIn.Interactivity
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}
