﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace CountMeIn.Interactivity
{
    public class FlickTrigger : TriggerBase<UIElement>
    {
        private static readonly Dictionary<Direction, Func<Point, bool>> Gestures = new Dictionary<Direction, Func<Point, bool>>
        {
            { Direction.Down, d => d.Y > 10 },
            { Direction.Left, d => d.X < 10 },
            { Direction.Right, d => d.X > 10 },
            { Direction.Up, d => d.Y < 10 }
        };

        public static readonly DependencyProperty DirectionProperty =
            DependencyProperty.Register("Direction", typeof(Direction), typeof(FlickTrigger), null);

        public Direction Direction
        {
            get
            {
                return (Direction)GetValue(DirectionProperty);
            }
            set
            {
                SetValue(DirectionProperty, value);
            }
        }

        protected override void OnAttached()
        {
            AssociatedObject.ManipulationCompleted += OnManipulationCompleted;
        }

    	protected override void OnDetaching()
        {
            AssociatedObject.ManipulationCompleted -= OnManipulationCompleted;   
        }

        private void OnManipulationCompleted(object sender, ManipulationCompletedEventArgs e)
        {
            if(!e.IsInertial)
                return;

            if(Gestures[Direction](e.TotalManipulation.Translation))
                InvokeActions(e);
        }
    }
}
