﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Expression.Interactivity.Core;

namespace CountMeIn
{
    public class CounterViewModel : INotifyPropertyChanged
    {
        private int currentCount;

        public CounterViewModel()
        {
            CurrentCount = 0;
            IncrementCount = new ActionCommand(p => CurrentCount += 1);
            DecrementCount = new ActionCommand(p => CurrentCount -= 1);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand IncrementCount
        {
            get; private set;
        }

        public ICommand DecrementCount
        {
            get;
            private set;
        }

        public int CurrentCount
        {
            get
            {
                return currentCount;
            }
            set
            {
                currentCount = value;
                OnPropertyChanged("CurrentCount");
            }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            var propertyChanged = PropertyChanged;

            if(propertyChanged != null)
                propertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
