﻿using System;

namespace CountMeIn
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
