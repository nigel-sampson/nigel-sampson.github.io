﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace ReactionTime
{
    public partial class MainPage
    {
        private readonly Random random = new Random();
        private readonly DispatcherTimer dispatchTimer = new DispatcherTimer();
        private readonly Stopwatch stopwatch = new Stopwatch();

        public MainPage()
        {
            InitializeComponent();

            dispatchTimer.Tick += OnBeginWaiting;
        }

        protected void OnReady(object sender, RoutedEventArgs e)
        {
            dispatchTimer.Interval = TimeSpan.FromSeconds(random.Next(2, 5));
            dispatchTimer.Start();

            VisualStateManager.GoToState(this, "Starting", true);
        }

        private void OnBeginWaiting(object sender, EventArgs e)
        {
            dispatchTimer.Stop();
            stopwatch.Start();

            VisualStateManager.GoToState(this, "Waiting", true);
        }

        protected void OnFinished(object sender, MouseButtonEventArgs e)
        {
            if(stopwatch.IsRunning)
            {
                stopwatch.Stop();

                Time.Text = String.Format("{0} ms", stopwatch.ElapsedMilliseconds);
            }
            else
            {
                dispatchTimer.Stop();
                Time.Text = "Too quick!";
            }

            VisualStateManager.GoToState(this, "Finished", true);
        }
    }
}