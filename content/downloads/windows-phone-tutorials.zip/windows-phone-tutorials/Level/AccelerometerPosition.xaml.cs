﻿using System;

namespace Level
{
	public class AccelerometerPosition
	{
		public double X
		{
			get; set;
		}

		public double Y
		{
			get; set;
		}

		public double Z
		{
			get; set;
		}
	}
}