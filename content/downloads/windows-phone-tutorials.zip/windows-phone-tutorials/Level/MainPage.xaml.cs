﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Devices;
using Microsoft.Devices.Sensors;
using Microsoft.Phone.Reactive;

namespace Level
{
	public partial class MainPage
	{
		private readonly Accelerometer accelerometer = new Accelerometer();
		private readonly Random random = new Random();

		public MainPage()
		{
			InitializeComponent();

			Loaded += OnLoaded;
		}

		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			var useEmulation = true;

			var observable = useEmulation ? CreateAccelerometerEmulator() : CreateObservableAccelerometer();

			observable
				.ObserveOnDispatcher()
				.Subscribe(OnPositionChanged);
		}

		private void OnPositionChanged(AccelerometerReading reading)
		{
		    var left = Canvas.GetLeft(Bubble) + reading.X * 5;
            var top = Canvas.GetTop(Bubble) + reading.Y * 5;

            if(left < 0 || left + Bubble.ActualWidth > ContentPanel.ActualWidth || top < 0 || top + Bubble.ActualHeight > ContentPanel.ActualHeight)
            {
                VibrateController.Default.Start(TimeSpan.FromMilliseconds(100));
                return;
            }

		    Canvas.SetLeft(Bubble, left);
		    Canvas.SetTop(Bubble, top);

		    var areOverlapping = left > 78 && left < 228 && top > 153.5 && top < 303.5;
 
		    TargetFill.Color = areOverlapping ? Color.FromArgb(255, 49, 154, 49) : Color.FromArgb(255, 230, 20, 0);
		}

		private IObservable<AccelerometerReading> CreateObservableAccelerometer()
		{
			var observable = Observable.FromEvent<AccelerometerReadingEventArgs>(
				e => accelerometer.ReadingChanged += e,
				e => accelerometer.ReadingChanged -= e)
				.Select(e => new AccelerometerReading
				{
					X = e.EventArgs.X,
					Y = e.EventArgs.Y,
					Z = e.EventArgs.Z
				});

			accelerometer.Start();

			return observable;
		}

		private IObservable<AccelerometerReading> CreateAccelerometerEmulator()
		{
		    return Observable.Timer(TimeSpan.FromSeconds(0), TimeSpan.FromMilliseconds(50))
                .Scan(new AccelerometerReading(), (current, t) =>
                {
                    var changeDirection = t % 20 == 0;

                    if(changeDirection)
                        return new AccelerometerReading
                        {
                            X = random.NextDouble() * 2.0 - 1.0,
                            Y = random.NextDouble() * 2.0 - 1.0,
                            Z = -1
                        };

                    return current;
                });
		}
	}
}