﻿using System;

namespace Level
{
	public class AccelerometerReading
	{
		public double X
		{
			get; set;
		}

		public double Y
		{
			get; set;
		}

		public double Z
		{
			get; set;
		}
	}
}