﻿using System;
using System.Windows;
using Microsoft.Phone.Tasks;

namespace Tasks
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnOpenPhone(object sender, RoutedEventArgs e)
        {
            var phoneCallTask = new PhoneCallTask
            {
                DisplayName = "Nigel Sampson",
                PhoneNumber = "021 555 5555"
            };

            phoneCallTask.Show();
        }

        private void OnOpenSMS(object sender, RoutedEventArgs e)
        {
            var smsComposeTask = new SmsComposeTask
            {
                To = "021 555 555",
                Body = "Windows Phone 7 SMS"
            };

            smsComposeTask.Show();
        }

        private void OnOpenEmail(object sender, RoutedEventArgs e)
        {
            var emailComposeTask = new EmailComposeTask
            {
                To = "nigel.sampson@compiledexperience.com",
                Subject = "Windows Phone 7 Email",
                Body = "Looking good!"
            };

            emailComposeTask.Show();
        }

        private void OnOpenMap(object sender, RoutedEventArgs e)
        {
            var searchTask = new SearchTask
            {
                SearchQuery = "46 Anglesea Street, Auckland 1011, New Zealand"
            };

            searchTask.Show();
        }

        private void OnOpenBrowser(object sender, RoutedEventArgs e)
        {
            var webBrowserTask = new WebBrowserTask
            {
                URL = "http://compiledexperience.com/blog"
            };

            webBrowserTask.Show();
        }
    }
}
