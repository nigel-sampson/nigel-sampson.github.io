﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace Snowfall
{
    public partial class MainPage
    {
        private readonly Random random = new Random();
        private readonly DispatcherTimer timer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(50)
        };

        private Point currentTransform = new Point(0, 0);

        public MainPage()
        {
            InitializeComponent();

            Loaded += OnLoaded;
            timer.Tick += OnTimerTicker;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            CreateInitialSnowflakes();

            timer.Start();
        }

        private void CreateInitialSnowflakes()
        {
            for(int i = 0; i < 25; i++)
            {
                var left = random.NextDouble() * ContentCanvas.ActualWidth;
                var top = random.NextDouble() * ContentCanvas.ActualHeight;
                var size = random.Next(10, 50);

                CreateSnowflake(left, top, size);
            }
        }

        private void CreateSnowflake(double left, double top, double size)
        {
            var snowflake = new Snowflake
            {
                Width = size,
                Height = size
            };

            Canvas.SetLeft(snowflake, left);
            Canvas.SetTop(snowflake, top);

            ContentCanvas.Children.Add(snowflake);
        }

        private void OnTimerTicker(object sender, EventArgs e)
        {
            var snowflakes = ContentCanvas.Children.OfType<Snowflake>().ToList();

            foreach(var snowflake in snowflakes)
            {
                snowflake.UpdatePosition(currentTransform);

                if(snowflake.IsOutOfBounds(ActualWidth, ActualHeight))
                {
                    ContentCanvas.Children.Remove(snowflake);
                    AddNewSnowflake();
                }

                currentTransform.X = currentTransform.X * 0.999d;
                currentTransform.Y = currentTransform.Y * 0.999d;
            }
        }

        private void AddNewSnowflake()
        {
            var left = random.NextDouble() * ContentCanvas.ActualWidth;
            var size = random.Next(10, 50);

            CreateSnowflake(left, 0, size);
        }

        protected void OnManipulationDelta(object sender, ManipulationDeltaEventArgs e)
        {
            currentTransform = e.CumulativeManipulation.Translation;
        }
    }
}
