﻿using System;
using System.Device.Location;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;
using Microsoft.Phone.Controls.Maps;

namespace QuakeML
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            LoadQuakes();
        }

        private void LoadQuakes()
        {
            var webClient = new WebClient();

            webClient.OpenReadCompleted += OnOpenReadCompleted;

            var uri = String.Format("http://magma.geonet.org.nz/services/quake/quakeml/1.0.1/query?startDate=2010-09-03&endDate=2010-09-05&magnitudeLower={0:0.0}&magnitudeUpper=8", Magnitude.Value);

            webClient.OpenReadAsync(new Uri(uri, UriKind.Absolute));
        }

        private void OnOpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    	{
    		var document = XDocument.Load(e.Result);

			if(document.Root == null)
				return;

    		var xmlns = XNamespace.Get("http://quakeml.org/xmlns/quakeml/1.0");

    		var events = from ev in document.Root.Descendants(xmlns + "event")
    		             select new
    		             {
							 Latitude = Convert.ToDouble(ev.Element(xmlns + "origin").Element(xmlns + "latitude").Element(xmlns + "value").Value),
							 Longitude = Convert.ToDouble(ev.Element(xmlns + "origin").Element(xmlns + "longitude").Element(xmlns + "value").Value),
							 Magnitude = Convert.ToDouble(ev.Element(xmlns + "magnitude").Element(xmlns + "mag").Element(xmlns + "value").Value),
    		             };

            QuakeLayer.Children.Clear();

    		foreach(var ev in events.OrderBy(ev => ev.Magnitude))
    		{
    			var accentBrush = (Brush)Application.Current.Resources["PhoneAccentBrush"];

    			var pin = new Pushpin
    			{
    				Location = new GeoCoordinate
    				{
    					Latitude = ev.Latitude,
    					Longitude = ev.Longitude
    				},
					Background = accentBrush,
					Content = ev.Magnitude.ToString("0.0"),
				};

				QuakeLayer.AddChild(pin, pin.Location);
    		}
    	}

        private void OnRefresh(object sender, RoutedEventArgs e)
        {
            LoadQuakes();
        }
    }
}