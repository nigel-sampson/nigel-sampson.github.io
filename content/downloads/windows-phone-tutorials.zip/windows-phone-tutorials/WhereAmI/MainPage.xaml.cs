﻿using System;
using System.Device.Location;
using System.Windows;
using Microsoft.Phone.Reactive;

namespace WhereAmI
{
	public partial class MainPage
	{
		private readonly Random random = new Random();
		private readonly GeoCoordinateWatcher geoCoordinateWatcher = new GeoCoordinateWatcher();

		public MainPage()
		{
			InitializeComponent();

			Loaded += OnLoaded;
		}

		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			var useEmulation = true;

			var observable = useEmulation ? CreateGeoPositionEmulator() : CreateObservableGeoPositionWatcher();

			observable
				.ObserveOnDispatcher()
				.Subscribe(OnPositionChanged);
		}

		private void OnPositionChanged(GeoCoordinate location)
		{
			Latitude.Text = location.Latitude.ToString();
			Longitude.Text = location.Longitude.ToString();

			Map.Center = location;
		}

		private IObservable<GeoCoordinate> CreateObservableGeoPositionWatcher()
		{
			var observable = Observable.FromEvent<GeoPositionChangedEventArgs<GeoCoordinate>>(
				e => geoCoordinateWatcher.PositionChanged += e,
				e => geoCoordinateWatcher.PositionChanged -= e)
				.Select(e => e.EventArgs.Position.Location);

			geoCoordinateWatcher.Start();

			return observable;
		}

		private IObservable<GeoCoordinate> CreateGeoPositionEmulator()
		{
			return Observable.Timer(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(10))
				.Select(l => CreateRandomCoordinate());
		}

		private GeoCoordinate CreateRandomCoordinate()
		{
			var latitude = (random.NextDouble() * 180.0) - 90.0;
			var longitude = (random.NextDouble() * 360.0) - 180.0;

			return new GeoCoordinate(latitude, longitude);
		}
	}
}