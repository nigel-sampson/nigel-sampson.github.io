﻿using System;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Windows;

namespace MyIP
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            var webClient = new WebClient();

            webClient.OpenReadCompleted += OnOpenReadCompleted;

            webClient.OpenReadAsync(new Uri("http://compiledexperience.com/windows-phone-7/my-ip", UriKind.Absolute));
        }

        private void OnOpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            var serializer = new DataContractJsonSerializer(typeof(IPResult));
            var ipResult = (IPResult)serializer.ReadObject(e.Result);

            IPAddress.Text = ipResult.IP;
        }
    }
}
