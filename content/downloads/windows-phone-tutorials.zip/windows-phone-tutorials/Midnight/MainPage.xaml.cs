﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace CompiledExperience.WP7.Midnight
{
	public partial class MainPage
	{
		private DispatcherTimer timer;

		public MainPage()
		{
			InitializeComponent();

			Loaded += OnLoaded;
		}

		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			timer = new DispatcherTimer
			{
				Interval = TimeSpan.FromSeconds(1)
			};

			timer.Tick += OnTick;

			timer.Start();
		}

		private void OnTick(object sender, EventArgs e)
		{
			var midnight = DateTime.Today.AddHours(24);
			var timeLeft = midnight - DateTime.Now;

			Countdown.Text = String.Format("{0:D2}:{1:D2}:{2:D2}", timeLeft.Hours, timeLeft.Minutes, timeLeft.Seconds);
		}
	}
}
