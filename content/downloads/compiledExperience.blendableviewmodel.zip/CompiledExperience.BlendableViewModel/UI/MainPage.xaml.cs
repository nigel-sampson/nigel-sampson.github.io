﻿using System;

namespace CompiledExperience.BlendableViewModel.UI
{
	public partial class MainPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}