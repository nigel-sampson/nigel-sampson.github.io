﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Browser;

namespace CompiledExperience.BlendableViewModel.UI
{
	public partial class App
	{
		public App()
		{
			Startup += OnStartup;
			UnhandledException += OnUnhandledException;

			InitializeComponent();
		}

		private void OnStartup(object sender, StartupEventArgs e)
		{
			RootVisual = new MainPage();
		}

		private static void OnUnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
		{
			if(Debugger.IsAttached)
				return;

			e.Handled = true;
			Deployment.Current.Dispatcher.BeginInvoke(() => ReportErrorToDOM(e));
		}

		private static void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
		{
			var errorMsg = e.ExceptionObject.Message + e.ExceptionObject.StackTrace;
			errorMsg = errorMsg.Replace('"', '\'').Replace("\r\n", @"\n");

			HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight Application " + errorMsg + "\");");
		}
	}
}