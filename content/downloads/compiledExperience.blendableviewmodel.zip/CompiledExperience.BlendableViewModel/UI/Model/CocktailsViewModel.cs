﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using CompiledExperience.BlendableViewModel.Core;
using CompiledExperience.BlendableViewModel.Core.Input;
using CompiledExperience.BlendableViewModel.Core.Model;
using CompiledExperience.BlendableViewModel.UI.CocktailService;

namespace CompiledExperience.BlendableViewModel.UI.Model
{
	public class CocktailsViewModel : ViewModelBase<CocktailsViewModel>
	{
		private readonly ICocktailService cocktailService;

		public CocktailsViewModel(ICocktailService cocktailService)
		{
			this.cocktailService = cocktailService;

			AvailableCocktails = new ObservableCollection<Cocktail>();
			SimilarCocktails = new ObservableCollection<Cocktail>();

			GetSimilarCocktailsCommand = new DelegateCommand<Cocktail>(GetSimilarCocktails);

			cocktailService.BeginGetCocktails(OnGetCocktails, null);
		}

private void OnGetCocktails(IAsyncResult ar) 
{
	var cocktails = cocktailService.EndGetCocktails(ar);

	InvokeOnUIThread(() => AvailableCocktails.AddRange(cocktails));
}

		public ObservableCollection<Cocktail> AvailableCocktails
		{
			get;
			set;
		}

		public ObservableCollection<Cocktail> SimilarCocktails
		{
			get;
			set;
		}

		public ICommand GetSimilarCocktailsCommand
		{
			get;
			private set;
		}

		protected void GetSimilarCocktails(Cocktail cocktail)
		{
			cocktailService.BeginGetCocktailsSimilarTo(cocktail, OnGetCocktailsSimilarTo, null);
		}

private void OnGetCocktailsSimilarTo(IAsyncResult ar)
{
	var cocktails = cocktailService.EndGetCocktailsSimilarTo(ar);

	InvokeOnUIThread(() => SimilarCocktails.Replace(cocktails));
}
	}
}