﻿using System;
using System.Windows.Threading;
using CompiledExperience.BlendableViewModel.UI.CocktailService;
using CompiledExperience.BlendableViewModel.UI.Model;
using Ninject.Core;

namespace CompiledExperience.BlendableViewModel.UI
{
public class CocktailModule : StandardModule
{
	public override void Load() 
	{
		Bind<CocktailsViewModel>().ToSelf();
		Bind<ICocktailService>().To<CocktailServiceClient>();
	}
}
}
