﻿using System;
using CompiledExperience.BlendableViewModel.UI.Model;
using Ninject.Core;

namespace CompiledExperience.BlendableViewModel.UI
{
public class ServiceLocator
{
	private readonly IKernel kernal;

	public ServiceLocator()
	{
		kernal = new StandardKernel(new CocktailModule());
	}

	public CocktailsViewModel CocktailsViewModel
	{
		get
		{
			return kernal.Get<CocktailsViewModel>();
		}
	}
}
}
