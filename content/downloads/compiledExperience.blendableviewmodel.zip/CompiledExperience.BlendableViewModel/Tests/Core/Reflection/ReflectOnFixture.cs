﻿using System;
using CompiledExperience.BlendableViewModel.Core.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CompiledExperience.BlendableViewModel.Tests.Core.Reflection
{
	[TestClass]
	public class ReflectOnFixture
	{
		[TestMethod]
		[ExpectedException(typeof(ArgumentNullException))]
		public void GetPropertyNameWithNullExpressionThrowsException()
		{
			ReflectOn<object>.GetPropertyName(null);
		}

		[TestMethod]
		public void GetPropertyNameWithSimpleExpressionReturnsPropertyName()
		{
			Assert.AreEqual("Length", ReflectOn<string>.GetPropertyName(s => s.Length));
		}
	}
}
