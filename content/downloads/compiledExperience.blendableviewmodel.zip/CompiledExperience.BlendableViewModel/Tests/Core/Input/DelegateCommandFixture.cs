﻿using System;
using CompiledExperience.BlendableViewModel.Core.Input;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CompiledExperience.BlendableViewModel.Tests.Core.Input
{
	[TestClass]
	public class DelegateCommandFixture
	{
		[TestMethod]
		[ExpectedException(typeof(ArgumentNullException))]
		public void ConstructorWithNullActionThrowsException()
		{
			new DelegateCommand<string>(null);
		}

		[TestMethod]
		public void ExecuteCallsActions()
		{
			var executed = false;
			var command = new DelegateCommand<object>(o => executed = true);

			command.Execute(null);

			Assert.IsTrue(executed);
		}

		[TestMethod]
		[ExpectedException(typeof(ArgumentNullException))]
		public void ConstructorWithNullPredicateThrowsException()
		{
			new DelegateCommand<string>(s => s.Trim(), null);
		}
	}
}
