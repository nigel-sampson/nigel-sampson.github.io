﻿using System;
using CompiledExperience.BlendableViewModel.Core.Model;

namespace CompiledExperience.BlendableViewModel.Tests.Core.Model
{
	public class SimpleViewModel : ViewModelBase<SimpleViewModel>
	{
		public string Name
		{
			get; set;
		}

		public void RaisePropertyChangedForName()
		{
			OnPropertyChanged(m => m.Name);
		}
	}
}
