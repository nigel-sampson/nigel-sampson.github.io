﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CompiledExperience.BlendableViewModel.Tests.Core.Model
{
	[TestClass]
	public class ViewModelBaseFixture
	{
		[TestMethod]
		public void OnPropertyChangedWithExpressionRaisesEvent()
		{
			var propertyRaised = false;

			var model = new SimpleViewModel();
			model.PropertyChanged += (s, e) => propertyRaised = e.PropertyName == "Name";

			model.RaisePropertyChangedForName();

			Assert.IsTrue(propertyRaised);
		}
	}
}