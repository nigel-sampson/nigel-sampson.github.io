﻿using System;
using System.Collections.Generic;
using System.Linq;
using CompiledExperience.BlendableViewModel.UI.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;

namespace CompiledExperience.BlendableViewModel.Tests.UI.Model
{
	//[TestClass]
	//public class CocktailsViewModelFixture
	//{
	//    private readonly List<Cocktail> sampleCocktails = new List<Cocktail>
	//        {
	//            new Cocktail
	//            {
	//                Id = 1,
	//                Ingredients = new string[] {},
	//                Name = "Test"
	//            }
	//        };

	//    [TestMethod]
	//    public void ConstuctionRetrievesAvailableCockstails()
	//    {
	//        var cocktailService = MockRepository.GenerateMock<ICocktailService>();

	//        cocktailService.Expect(c => c.GetCocktails()).Return(Enumerable.Empty<Cocktail>());

	//        new CocktailsViewModel(cocktailService);

	//        cocktailService.VerifyAllExpectations();
	//    }

	//    [TestMethod]
	//    public void ConstuctionExposesAvailableCockstails()
	//    {
	//        var cocktailService = MockRepository.GenerateStub<ICocktailService>();

	//        cocktailService.Stub(c => c.GetCocktails()).Return(sampleCocktails);

	//        var viewModel = new CocktailsViewModel(cocktailService);

	//        Assert.AreEqual(sampleCocktails.Count, viewModel.AvailableCocktails.Count);
	//    }

	//    [TestMethod]
	//    public void GetSimilarCocktailsForwardsCommandParameter()
	//    {
	//        var selectedCocktail = new Cocktail();

	//        var cocktailService = MockRepository.GenerateMock<ICocktailService>();

	//        cocktailService.Stub(c => c.GetCocktails()).Return(Enumerable.Empty<Cocktail>());
	//        cocktailService.Expect(c => c.GetCocktailsSimilarTo(selectedCocktail)).Return(Enumerable.Empty<Cocktail>());

	//        var viewModel = new CocktailsViewModel(cocktailService);

	//        viewModel.GetSimilarCocktailsCommand.Execute(selectedCocktail);

	//        cocktailService.VerifyAllExpectations();
	//    }

	//    [TestMethod]
	//    public void GetSimilarCocktailsExposesSimilarCocktails()
	//    {
	//        var selectedCocktail = new Cocktail();

	//        var cocktailService = MockRepository.GenerateMock<ICocktailService>();

	//        cocktailService.Stub(c => c.GetCocktails()).Return(Enumerable.Empty<Cocktail>());
	//        cocktailService.Stub(c => c.GetCocktailsSimilarTo(selectedCocktail)).Return(sampleCocktails);

	//        var viewModel = new CocktailsViewModel(cocktailService);

	//        viewModel.GetSimilarCocktailsCommand.Execute(selectedCocktail);

	//        Assert.AreEqual(sampleCocktails.Count, viewModel.SimilarCocktails.Count);
	//    }
	//}
}
