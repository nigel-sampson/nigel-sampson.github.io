﻿using System;
using System.Collections.Generic;

namespace CompiledExperience.BlendableViewModel.Web.Services
{
	public class Cocktail
	{
		public int Id
		{
			get; set;
		}

		public string Name
		{
			get; set;
		}

		public IEnumerable<string> Ingredients
		{
			get; set;
		}
	}
}