﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Activation;

namespace CompiledExperience.BlendableViewModel.Web.Services
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class CocktailService : ICocktailService
	{
		private readonly List<Cocktail> cocktails = new List<Cocktail>
		{
			new Cocktail
			{
				Id = 1,
				Name = "Black Russian",
				Ingredients = new [] { "Vodka", "Kahlua" }
			},
			new Cocktail
			{
				Id = 2,
				Name = "White Russian",
				Ingredients = new[] { "Vodka", "Cream", "Kahlua" }
			},
			new Cocktail
			{
				Id = 3,
				Name = "Gin and Tonic",
				Ingredients = new[] { "Gin", "Tonic" }
			}
		};

		public IEnumerable<Cocktail> GetCocktails()
		{
			return cocktails;
		}

		public IEnumerable<Cocktail> GetCocktailsSimilarTo(Cocktail cocktail)
		{
			return from c in cocktails
			       where c.Ingredients.Intersect(cocktail.Ingredients).Count() >= 2 && c.Id != cocktail.Id
			       select c;
		}
	}
}