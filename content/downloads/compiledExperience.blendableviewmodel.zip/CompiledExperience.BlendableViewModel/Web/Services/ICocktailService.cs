using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace CompiledExperience.BlendableViewModel.Web.Services
{
[ServiceContract]
public interface ICocktailService
{
	[OperationContract]
	IEnumerable<Cocktail> GetCocktails();

	[OperationContract]
	IEnumerable<Cocktail> GetCocktailsSimilarTo(Cocktail cocktail);
}
}