﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CompiledExperience.BlendableViewModel.Core
{
	public static class ObservableCollectionsExtensions
	{
		public static void AddRange<T>(this ObservableCollection<T> collection, IEnumerable<T> items)
		{
			if(collection == null)
				throw new ArgumentNullException("collection");

			if(items == null)
				throw new ArgumentNullException("items");

			foreach(var item in items)
			{
				collection.Add(item);
			}
		}

		public static void Replace<T>(this ObservableCollection<T> collection, IEnumerable<T> items)
		{
			if(collection == null)
				throw new ArgumentNullException("collection");

			if(items == null)
				throw new ArgumentNullException("items");

			collection.Clear();
			collection.AddRange(items);
		}
	}
}
