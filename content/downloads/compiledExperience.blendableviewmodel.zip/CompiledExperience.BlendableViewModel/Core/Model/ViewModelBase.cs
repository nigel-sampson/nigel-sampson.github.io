﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Windows;
using System.Windows.Threading;
using CompiledExperience.BlendableViewModel.Core.Reflection;

namespace CompiledExperience.BlendableViewModel.Core.Model
{
	public abstract class ViewModelBase<T> : INotifyPropertyChanged where T : ViewModelBase<T>
	{
		public event PropertyChangedEventHandler PropertyChanged;

protected ViewModelBase()
{
	Dispatcher = Deployment.Current.Dispatcher;
}

protected Dispatcher Dispatcher
{
	get; private set;
}

protected void InvokeOnUIThread(Action action)
{
	Dispatcher.BeginInvoke(action);
}

		protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
		{
			var propertyChanged = PropertyChanged;

			if(propertyChanged != null)
				propertyChanged(this, e);
		}

		protected virtual void OnPropertyChanged(params Expression<Func<T, object>>[] expressions)
		{
			foreach(var expression in expressions)
			{
				OnPropertyChanged(new PropertyChangedEventArgs(ReflectOn<T>.GetPropertyName(expression)));
			}
		}
	}
}