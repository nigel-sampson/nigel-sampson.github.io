﻿using System;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interactivity;
using CompiledExperience.BlendableViewModel.Core.Interactivity.BindingHelpers;

namespace CompiledExperience.BlendableViewModel.Core.Interactivity
{
	public class ExecuteCommandAction : TriggerAction<FrameworkElement>
	{
		private readonly BindingListener commandListener;
		private readonly BindingListener commandParameterListener;

		public ExecuteCommandAction()
		{
			commandListener = new BindingListener();
			commandParameterListener = new BindingListener();
		}

		public static readonly DependencyProperty CommandProperty =
			DependencyProperty.Register("Command", typeof(Binding), typeof(ExecuteCommandAction), new PropertyMetadata(null, OnCommandChanged));

		public static readonly DependencyProperty CommandParameterProperty =
			DependencyProperty.Register("CommandParameter", typeof(Binding), typeof(ExecuteCommandAction), new PropertyMetadata(null, OnCommandParameterChanged));

		public Binding Command
		{
			get
			{
				return (Binding)GetValue(CommandProperty);
			}
			set
			{
				SetValue(CommandProperty, value);
			}
		}

		public Binding CommandParameter
		{
			get
			{
				return (Binding)GetValue(CommandParameterProperty);
			}
			set
			{
				SetValue(CommandParameterProperty, value);
			}
		}

		private static void OnCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ExecuteCommandAction)d).OnCommandBindingChanged(e);
		}

		private static void OnCommandParameterChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ExecuteCommandAction)d).OnCommandParameterBindingChanged(e);
		}

		private void OnCommandBindingChanged(DependencyPropertyChangedEventArgs e)
		{
			commandListener.Binding = (Binding)e.NewValue;
		}

		private void OnCommandParameterBindingChanged(DependencyPropertyChangedEventArgs e)
		{
			commandParameterListener.Binding = (Binding)e.NewValue;
		}

		protected override void OnAttached()
		{
			base.OnAttached();

			commandListener.Element = AssociatedObject;
			commandParameterListener.Element = AssociatedObject;
		}

		protected override void OnDetaching()
		{
			base.OnDetaching();

			commandListener.Element = null;
			commandParameterListener.Element = null;
		}

		protected override void Invoke(object parameter)
		{
			var command = commandListener.Value as ICommand;

			if(command == null)
				return;

			var commandParameter = commandParameterListener.Value;

			if(command.CanExecute(commandParameter))
				command.Execute(commandParameter);
		}
	}
}
