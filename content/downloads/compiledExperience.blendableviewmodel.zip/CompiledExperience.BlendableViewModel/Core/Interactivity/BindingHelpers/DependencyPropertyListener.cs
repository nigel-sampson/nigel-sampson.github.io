using System;
using System.Windows;
using System.Windows.Data;

namespace CompiledExperience.BlendableViewModel.Core.Interactivity.BindingHelpers
{
	public class DependencyPropertyListener
	{
		private static int Index;
		private readonly DependencyProperty property;
		private FrameworkElement target;

		public DependencyPropertyListener()
		{
			property = DependencyProperty.RegisterAttached("DependencyPropertyListener" + Index++, typeof(object), typeof(DependencyPropertyListener),
			                                               new PropertyMetadata(null, HandleValueChanged));
		}

		public event EventHandler<BindingChangedEventArgs> Changed;

		private void HandleValueChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			if(Changed != null)
				Changed(this, new BindingChangedEventArgs(e));
		}

		public void Attach(FrameworkElement element, Binding binding)
		{
			if(target != null)
				throw new Exception("Cannot attach an already attached listener");

			target = element;

			target.SetBinding(property, binding);
		}

		public void Detach()
		{
			target.ClearValue(property);
			target = null;
		}
	}
}