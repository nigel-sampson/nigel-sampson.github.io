﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Data;

namespace CompiledExperience.BlendableViewModel.Core.Interactivity.BindingHelpers
{
	public class BindingListener
	{
		private static readonly List<DependencyPropertyListener> FreeListeners = new List<DependencyPropertyListener>();

		private Binding binding;
		private DependencyPropertyListener listener;
		private FrameworkElement target;

		public Binding Binding
		{
			get
			{
				return binding;
			}
			set
			{
				binding = value;
				Attach();
			}
		}

		public FrameworkElement Element
		{
			get
			{
				return target;
			}
			set
			{
				target = value;
				Attach();
			}
		}

		public object Value { get; private set; }


		private void Attach()
		{
			Detach();

			if(target == null || binding == null) 
				return;

			listener = GetListener();
			listener.Attach(target, binding);
		}

		private void Detach()
		{
			if(listener != null)
				ReturnListener();
		}

		private DependencyPropertyListener GetListener()
		{
			DependencyPropertyListener freeListener;

			if(FreeListeners.Count != 0)
			{
				freeListener = FreeListeners[FreeListeners.Count - 1];
				FreeListeners.RemoveAt(FreeListeners.Count - 1);

				return freeListener;
			}

			freeListener = new DependencyPropertyListener();

			freeListener.Changed += HandleValueChanged;

			return freeListener;
		}

		private void ReturnListener()
		{
			listener.Changed -= HandleValueChanged;

			FreeListeners.Add(listener);

			listener = null;
		}

		private void HandleValueChanged(object sender, BindingChangedEventArgs e)
		{
			Value = e.EventArgs.NewValue;
		}
	}
}