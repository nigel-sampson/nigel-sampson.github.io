using System;
using System.Windows;

namespace CompiledExperience.BlendableViewModel.Core.Interactivity.BindingHelpers
{
	public class BindingChangedEventArgs : EventArgs
	{
		public BindingChangedEventArgs(DependencyPropertyChangedEventArgs e)
		{
			EventArgs = e;
		}

		public DependencyPropertyChangedEventArgs EventArgs { get; private set; }
	}
}