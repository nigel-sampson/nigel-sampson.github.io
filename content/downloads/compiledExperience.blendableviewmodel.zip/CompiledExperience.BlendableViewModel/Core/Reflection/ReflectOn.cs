﻿using System;
using System.Linq.Expressions;

namespace CompiledExperience.BlendableViewModel.Core.Reflection
{
	public static class ReflectOn<T>
	{
		public static string GetPropertyName(Expression<Func<T, object>> propertyExpression)
		{
			if(propertyExpression == null)
				throw new ArgumentNullException("propertyExpression");

			var expression = propertyExpression.Body;

			if(expression is UnaryExpression)
			{
				expression = ((UnaryExpression)expression).Operand;
			}

			if(expression is MemberExpression)
			{
				return ((MemberExpression)expression).Member.Name;
			}	

			throw new InvalidOperationException("Could not determine property name from propertyExpression " + propertyExpression.ToString());
		}
	}
}
