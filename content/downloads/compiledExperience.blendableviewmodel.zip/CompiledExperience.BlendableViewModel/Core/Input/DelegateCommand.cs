using System;
using System.Windows.Input;

namespace CompiledExperience.BlendableViewModel.Core.Input
{
public class DelegateCommand<T> : ICommand
{
	public event EventHandler CanExecuteChanged;

	private readonly Action<T> action;
	private readonly Func<T, bool> predicate;

	public DelegateCommand(Action<T> action)
	{
		if(action == null)
			throw new ArgumentNullException("action");

		this.action = action;
		predicate = t => true;
	}

	public DelegateCommand(Action<T> action, Func<T, bool> predicate)
	{
		if(action == null)
			throw new ArgumentNullException("action");

		if(predicate == null)
			throw new ArgumentNullException("predicate");

		this.action = action;
		this.predicate = predicate;
	}

	protected virtual void OnCanExecuteChanged(EventArgs e)
	{
		var canExecuteChanged = CanExecuteChanged;

		if(canExecuteChanged != null)
			canExecuteChanged(this, e);
	}

	public void RaiseCanExecuteChanged()
	{
		OnCanExecuteChanged(EventArgs.Empty);
	}

	public bool CanExecute(object parameter)
	{
		return predicate((T)parameter);
	}

	public void Execute(object parameter)
	{
		action((T)parameter);
	}
}
}