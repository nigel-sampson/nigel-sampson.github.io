﻿using System;
using System.Windows;

namespace CompiledExperience.Phone.Toolkit
{
	public partial class MainPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

		private void OnSimpleStatus(object sender, RoutedEventArgs e)
		{
			NavigationService.Navigate(new Uri("/SimpleStatus.xaml", UriKind.Relative));
		}

		private void OnSimpleStatusViewModel(object sender, RoutedEventArgs e)
		{
			NavigationService.Navigate(new Uri("/SimpleStatusViewModel.xaml", UriKind.Relative));
		}

		private void OnSimpleNotification(object sender, RoutedEventArgs e)
		{
			NavigationService.Navigate(new Uri("/SimpleNotification.xaml", UriKind.Relative));
		}

        private void OnSimpleNotificationViewModel(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/SimpleNotificationViewModel.xaml", UriKind.Relative));
        }
	}
}