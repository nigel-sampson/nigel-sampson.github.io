﻿using System;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	public class StatusSource : IStatusSource
	{
		public StatusSource()
		{
			Text = String.Empty;
			InProgress = false;
		}

		public event EventHandler StatusChanged;
		public event EventHandler StatusCleared;

		protected virtual void OnStatusChanged(EventArgs e)
		{
			var statusChanged = StatusChanged;

			if(statusChanged != null)
				statusChanged(this, e);
		}

		protected virtual void OnStatusCleared(EventArgs e)
		{
			var statusCleared = StatusCleared;

			if(statusCleared != null)
				statusCleared(this, e);
		}

		public void Display(string text, bool inProgress)
		{
			Text = text;
			InProgress = inProgress;

			OnStatusChanged(EventArgs.Empty);
		}

		public void Clear()
		{
            InProgress = false;
			OnStatusCleared(EventArgs.Empty);
		}

		public string Text
		{
			get;
			private set;
		}

		public bool InProgress
		{
			get;
			private set;
		}
	}
}
