using System;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	public interface IStatusSource
	{
		event EventHandler StatusChanged;
		event EventHandler StatusCleared;
		string Text { get; }
		bool InProgress { get; }
		void Display(string text, bool inProgress);
		void Clear();
	}
}