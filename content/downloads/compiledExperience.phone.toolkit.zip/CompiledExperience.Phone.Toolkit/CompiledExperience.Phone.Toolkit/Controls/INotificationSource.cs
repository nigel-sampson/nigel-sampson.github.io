﻿using System;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	public interface INotificationSource
	{
		void Display(string title, string text, Action onDimiss = null);

		event EventHandler NotificationChanged;

		string Title { get; }
		string Text { get; }

		Action OnDimiss { get; }
	}
}