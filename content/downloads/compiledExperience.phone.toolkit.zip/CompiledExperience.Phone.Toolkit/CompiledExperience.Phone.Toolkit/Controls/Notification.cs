﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Devices;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	public class Notification : Control
	{
		private enum NotificationState
		{
			Dismissed,
			Opened
		}

		public static readonly DependencyProperty TitleProperty =
			DependencyProperty.Register("Title", typeof(string), typeof(Notification), null);

		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register("Text", typeof(string), typeof(Notification), null);

        public static readonly DependencyProperty OnDismissProperty =
            DependencyProperty.Register("OnDismiss", typeof(Action), typeof(Notification), null);

		public static readonly DependencyProperty SourceProperty =
			DependencyProperty.Register("Source", typeof(INotificationSource), typeof(Notification), new PropertyMetadata(OnSourceChanged));

		public Notification()
		{
			DefaultStyleKey = typeof(Notification);
		}

		public override void OnApplyTemplate()
		{
			SetState(NotificationState.Dismissed, false);
			base.OnApplyTemplate();
		}

		public string Title
		{
			get
			{
				return (string)GetValue(TitleProperty);
			}
			set
			{
				SetValue(TitleProperty, value);
			}
		}

		public string Text
		{
			get
			{
				return (string)GetValue(TextProperty);
			}
			set
			{
				SetValue(TextProperty, value);
			}
		}

        public Action OnDismiss
        {
            get
            {
                return (Action)GetValue(OnDismissProperty);
            }
            set
            {
                SetValue(OnDismissProperty, value);
            }
        }

		public INotificationSource Source
		{
			get
			{
				return (INotificationSource)GetValue(SourceProperty);
			}
			set
			{
				SetValue(SourceProperty, value);
			}
		}

		private void SetState(NotificationState state, bool transition)
		{
			VisualStateManager.GoToState(this, state.ToString(), transition);
		}

		private static void OnSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var notification = (Notification)d;

			notification.OnSourceChanged((INotificationSource)e.OldValue, (INotificationSource)e.NewValue);
		}

		private void OnSourceChanged(INotificationSource oldValue, INotificationSource newValue)
		{
			if(oldValue != null)
				oldValue.NotificationChanged -= OnNotificationChanged;

			if(newValue != null)
				newValue.NotificationChanged += OnNotificationChanged;
		}

		private void OnNotificationChanged(object sender, EventArgs e)
		{
			Display(Source.Title, Source.Text, Source.OnDimiss);
		}

		protected override void OnMouseLeftButtonDown(System.Windows.Input.MouseButtonEventArgs e)
		{
			e.Handled = true;

			Dismiss();
		}

		public void Dismiss()
		{
			SetState(NotificationState.Dismissed, true);

            if(OnDismiss != null)
                OnDismiss();
		}

		public void Display(string title, string text, Action onDismiss = null)
		{
			Title = title;
			Text = text;
            OnDismiss = onDismiss;

			SetState(NotificationState.Opened, true);

			VibrateController.Default.Start(TimeSpan.FromMilliseconds(50));
		}
	}
}
