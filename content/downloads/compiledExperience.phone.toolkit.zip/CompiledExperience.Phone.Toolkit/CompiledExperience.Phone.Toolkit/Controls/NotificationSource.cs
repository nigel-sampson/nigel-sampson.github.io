﻿using System;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	public class NotificationSource : INotificationSource
	{
		public event EventHandler NotificationChanged;

		public NotificationSource()
		{
			Title = String.Empty;
			Text = String.Empty;
		}

		protected virtual void OnNotificationChanged(EventArgs e)
		{
			var onNotificationChanged = NotificationChanged;

			if(onNotificationChanged != null)
				onNotificationChanged(this, e);
		}

		public void Display(string title, string text, Action onDimiss = null)
		{
			Title = title;
			Text = text;
			OnDimiss = onDimiss;

			OnNotificationChanged(EventArgs.Empty);
		}

		public string Title
		{
			get;
			private set;
		}

		public string Text
		{
			get;
			private set;
		}

		public Action OnDimiss
		{
			get;
			private set;
		}
	}
}
