﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CompiledExperience.Phone.Toolkit.Controls
{
	[TemplateVisualState(GroupName = "Status", Name = "Clear")]
	[TemplateVisualState(GroupName = "Status", Name = "Displayed")]
	public class StatusIndicator : Control
	{
		private enum IndicatorState
		{
			Clear,
			Displayed
		}

		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register("Text", typeof(string), typeof(StatusIndicator), null);

		public static readonly DependencyProperty InProgressProperty =
			DependencyProperty.Register("InProgress", typeof(bool), typeof(StatusIndicator), null);

		public static readonly DependencyProperty SourceProperty =
			DependencyProperty.Register("Source", typeof(IStatusSource), typeof(StatusIndicator), new PropertyMetadata(OnSourceChanged));

		public StatusIndicator()
		{
			DefaultStyleKey = typeof(StatusIndicator);
		}


		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			SetState(IndicatorState.Clear, false);
		}

		public void Display(string text, bool inProgress)
		{
			Text = text;
			InProgress = inProgress;

			SetState(IndicatorState.Displayed, true);
		}

		public void Clear()
		{
			SetState(IndicatorState.Clear, true);
		}

		public string Text
		{
			get
			{
				return (string)GetValue(TextProperty);
			}
			set
			{
				SetValue(TextProperty, value);
			}
		}

		public bool InProgress
		{
			get
			{
				return (bool)GetValue(InProgressProperty);
			}
			set
			{
				SetValue(InProgressProperty, value);
			}
		}

		private void SetState(IndicatorState state, bool transition)
		{
			VisualStateManager.GoToState(this, state.ToString(), transition);
		}

		public IStatusSource Source
		{
			get
			{
				return (IStatusSource)GetValue(SourceProperty);
			}
			set
			{
				SetValue(SourceProperty, value);
			}
		}

		private static void OnSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var statusIndicator = (StatusIndicator)d;

			statusIndicator.OnSourceChanged((IStatusSource)e.OldValue, (IStatusSource)e.NewValue);
		}

		private void OnSourceChanged(IStatusSource oldValue, IStatusSource newValue)
		{
			if(oldValue != null)
			{
				oldValue.StatusChanged -= OnStatusChanged;
				oldValue.StatusCleared -= OnStatusCleared;
			}

			if(newValue != null)
			{
				newValue.StatusChanged += OnStatusChanged;
				newValue.StatusCleared += OnStatusCleared;
			}
		}

		private void OnStatusCleared(object sender, EventArgs e)
		{
			SetState(IndicatorState.Clear, true);
		}

		private void OnStatusChanged(object sender, EventArgs e)
		{
			Text = Source.Text;
			InProgress = Source.InProgress;

			SetState(IndicatorState.Displayed, true);
		}
	}
}
