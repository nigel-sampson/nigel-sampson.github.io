﻿using System;
using System.Windows;

namespace CompiledExperience.Phone.Toolkit
{
	public partial class SimpleNotification
	{
		public SimpleNotification()
		{
			InitializeComponent();
		}

		private void OnDisplay(object sender, RoutedEventArgs e)
		{
            Notification.Display("Title", "Text", () =>
            {
                MessageBox.Show("Dismissed", "The notification control has been dimissed", MessageBoxButton.OK);
            });
		}

		private void OnDismiss(object sender, RoutedEventArgs e)
		{
			Notification.Dismiss();
		}
	}
}