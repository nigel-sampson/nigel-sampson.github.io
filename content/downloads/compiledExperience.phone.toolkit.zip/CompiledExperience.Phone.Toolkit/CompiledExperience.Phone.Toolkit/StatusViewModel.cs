﻿using System;
using CompiledExperience.Phone.Toolkit.Controls;

namespace CompiledExperience.Phone.Toolkit
{
	public class StatusViewModel
	{
		public StatusViewModel()
		{
			Status = new StatusSource();
		}

		public IStatusSource Status
		{
			get; set;
		}

		public void Display()
		{
			Status.Display("Updating", true);
		}

		public void Finish()
		{
			Status.Display(String.Format("Updated {0:d}", DateTime.Now), false);
		}
	}
}
