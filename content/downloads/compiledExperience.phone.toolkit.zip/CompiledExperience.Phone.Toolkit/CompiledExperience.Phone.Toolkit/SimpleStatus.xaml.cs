﻿using System;
using System.Windows;

namespace CompiledExperience.Phone.Toolkit
{
	public partial class SimpleStatus
	{
		public SimpleStatus()
		{
			InitializeComponent();
		}

		private void OnDisplay(object sender, RoutedEventArgs e)
		{
			Status.Display("Loading...", true);
		}

		private void OnClear(object sender, RoutedEventArgs e)
		{
			Status.Clear();
		}
	}
}