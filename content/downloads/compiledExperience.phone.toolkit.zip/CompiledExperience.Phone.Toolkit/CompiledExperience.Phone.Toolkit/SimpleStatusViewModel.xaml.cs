﻿using System;
using System.Windows;

namespace CompiledExperience.Phone.Toolkit
{
	public partial class SimpleStatusViewModel
	{
		public SimpleStatusViewModel()
		{
			InitializeComponent();
		}

		public StatusViewModel ViewModel
		{
			get
			{
				return (StatusViewModel)DataContext;
			}
		}

		private void OnDisplay(object sender, RoutedEventArgs e)
		{
			ViewModel.Display();
		}

		private void OnFinish(object sender, RoutedEventArgs e)
		{
			ViewModel.Finish();
		}
	}
}