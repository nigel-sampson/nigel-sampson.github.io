﻿using System;
using System.Windows;

namespace CompiledExperience.Phone.Toolkit
{
    public partial class SimpleNotificationViewModel
    {
        public SimpleNotificationViewModel()
        {
            InitializeComponent();
        }

        public NotificationViewModel ViewModel
        {
            get
            {
                return (NotificationViewModel)DataContext;
            }
        }

        private void OnDisplay(object sender, RoutedEventArgs e)
        {
            ViewModel.Display();
        }
    }
}