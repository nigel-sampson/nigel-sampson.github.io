﻿using System;
using System.Windows;
using CompiledExperience.Phone.Toolkit.Controls;

namespace CompiledExperience.Phone.Toolkit
{
    public class NotificationViewModel
    {
        public NotificationViewModel()
        {
            Notifications = new NotificationSource();
        }

        public INotificationSource Notifications
        {
            get;
            set;
        }

        public void Display()
        {
            Notifications.Display("Security", "Tap to authenticate the application", () =>
                {
                    MessageBox.Show("Authenticated", "The application has been authenticated against the server", MessageBoxButton.OK);
                });
        }
    }
}
