﻿using System;
using Caliburn.Ninject;
using Caliburn.Phone.ViewModels;
using Microsoft.Practices.ServiceLocation;
using Ninject;

namespace Caliburn.Phone
{
	public partial class App
	{
		public App()
		{
			InitializeComponent();
		}

		protected override IServiceLocator CreateContainer()
		{
			var kernel = new StandardKernel();

			return new NinjectAdapter(kernel);
		}

		protected override object CreateRootModel()
		{
			return new ShellViewModel();
		}
	}
}
