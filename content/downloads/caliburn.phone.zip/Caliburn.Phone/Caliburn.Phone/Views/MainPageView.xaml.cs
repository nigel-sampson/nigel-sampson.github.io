﻿using System;

namespace Caliburn.Phone.Views
{
	public partial class MainPageView
	{
		public MainPageView()
		{
			InitializeComponent();
		}
	}
}