﻿using System;
using System.Windows;
using System.Windows.Navigation;
using Caliburn.PresentationFramework.ApplicationModel;
using Microsoft.Practices.ServiceLocation;

namespace Caliburn.Phone.Views
{
	public partial class ShellView
	{
		private readonly IServiceLocator serviceLocator;
		private readonly IBinder binder;

		public ShellView(IServiceLocator serviceLocator, IBinder binder)
		{
			this.serviceLocator = serviceLocator;
			this.binder = binder;

			InitializeComponent();

			Loaded += OnLoaded;
			Navigated += OnNavigated;
		}

		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			// I prefer this to start navigation than the _default Task in WMAppMainfest.xml
			Navigate(new Uri("/Views/MainPageView.xaml", UriKind.Relative));
		}

		private void OnNavigated(object sender, NavigationEventArgs e)
		{
			var viewModel = BuildViewModel(e);

			binder.Bind(viewModel, e.Content, null);

			var presenter = viewModel as IPresenter;

			if(presenter == null)
				return;

			presenter.Initialize();
			presenter.Activate();
		}

		private object BuildViewModel(NavigationEventArgs e)
		{
			var viewType = e.Content.GetType();

			var viewModelTypeName = viewType.FullName.Replace("View", "ViewModel");
			var viewModelType = Type.GetType(viewModelTypeName);

			return serviceLocator.GetInstance(viewModelType);
		}
	}
}