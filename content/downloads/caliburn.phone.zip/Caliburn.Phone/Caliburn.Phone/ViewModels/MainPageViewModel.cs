﻿using System;
using Caliburn.PresentationFramework.ApplicationModel;

namespace Caliburn.Phone.ViewModels
{
	public class MainPageViewModel : Presenter
	{
		private string message;

		public string Message
		{
			get
			{
				return message;
			}
			set
			{
				message = value;
				NotifyOfPropertyChange(() => Message);
			}
		}

		public bool CanSayHello(string name)
		{
			return !String.IsNullOrEmpty(name);
		}

		public void SayHello(string name)
		{
			Message = String.Format("Hello {0}.", name);
		}
	}
}
