﻿using System;
using Caliburn.PresentationFramework.ApplicationModel;

namespace Caliburn.Phone.ViewModels
{
	public class ShellViewModel : Presenter
	{

	}
}
